#ifndef CLAUSE_HH
#define CLAUSE_HH


#include "Variable.hh"
#include "Literal.hh"
#include "Debug.hh"


//#include "BasicClause.hh"
//#include "ConstAssignClause.hh"
#include "WatchedClause.hh"
#include "SmartClause.hh"
//#include "SmartWatchedClause.hh"





#endif // CLAUSE_HH defined
